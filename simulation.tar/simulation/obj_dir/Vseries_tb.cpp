// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vseries_tb__pch.h"

//============================================================
// Constructors

Vseries_tb::Vseries_tb(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vseries_tb__Syms(contextp(), _vcname__, this)}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vseries_tb::Vseries_tb(const char* _vcname__)
    : Vseries_tb(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vseries_tb::~Vseries_tb() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vseries_tb___024root___eval_debug_assertions(Vseries_tb___024root* vlSelf);
#endif  // VL_DEBUG
void Vseries_tb___024root___eval_static(Vseries_tb___024root* vlSelf);
void Vseries_tb___024root___eval_initial(Vseries_tb___024root* vlSelf);
void Vseries_tb___024root___eval_settle(Vseries_tb___024root* vlSelf);
void Vseries_tb___024root___eval(Vseries_tb___024root* vlSelf);

void Vseries_tb::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vseries_tb::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vseries_tb___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        vlSymsp->__Vm_didInit = true;
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vseries_tb___024root___eval_static(&(vlSymsp->TOP));
        Vseries_tb___024root___eval_initial(&(vlSymsp->TOP));
        Vseries_tb___024root___eval_settle(&(vlSymsp->TOP));
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vseries_tb___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vseries_tb::eventsPending() { return !vlSymsp->TOP.__VdlySched.empty(); }

uint64_t Vseries_tb::nextTimeSlot() { return vlSymsp->TOP.__VdlySched.nextTimeSlot(); }

//============================================================
// Utilities

const char* Vseries_tb::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vseries_tb___024root___eval_final(Vseries_tb___024root* vlSelf);

VL_ATTR_COLD void Vseries_tb::final() {
    Vseries_tb___024root___eval_final(&(vlSymsp->TOP));
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vseries_tb::hierName() const { return vlSymsp->name(); }
const char* Vseries_tb::modelName() const { return "Vseries_tb"; }
unsigned Vseries_tb::threads() const { return 1; }
void Vseries_tb::prepareClone() const { contextp()->prepareClone(); }
void Vseries_tb::atClone() const {
    contextp()->threadPoolpOnClone();
}

//============================================================
// Trace configuration

VL_ATTR_COLD void Vseries_tb::trace(VerilatedVcdC* tfp, int levels, int options) {
    vl_fatal(__FILE__, __LINE__, __FILE__,"'Vseries_tb::trace()' called on model that was Verilated without --trace option");
}
