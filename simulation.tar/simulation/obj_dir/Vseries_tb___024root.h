// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vseries_tb.h for the primary calling header

#ifndef VERILATED_VSERIES_TB___024ROOT_H_
#define VERILATED_VSERIES_TB___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_timing.h"


class Vseries_tb__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vseries_tb___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ jtag_tb__DOT__clk;
    CData/*0:0*/ jtag_tb__DOT__tms;
    CData/*0:0*/ jtag_tb__DOT__tdi;
    CData/*0:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tdo0;
    CData/*0:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tdo_user;
    CData/*4:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR;
    CData/*4:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR;
    CData/*7:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN;
    CData/*7:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR;
    CData/*0:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BYPASS_SR;
    CData/*0:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0;
    CData/*0:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tdo_user;
    CData/*4:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR;
    CData/*4:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR;
    CData/*7:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN;
    CData/*7:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR;
    CData/*0:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BYPASS_SR;
    CData/*0:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0;
    CData/*0:0*/ __VstlFirstIteration;
    CData/*0:0*/ __Vtrigprevexpr___TOP__jtag_tb__DOT__clk__0;
    CData/*0:0*/ __VactContinue;
    IData/*31:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state;
    IData/*31:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR;
    IData/*31:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state;
    IData/*31:0*/ jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR;
    IData/*31:0*/ __VactIterCount;
    VlDelayScheduler __VdlySched;
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<2> __VactTriggered;
    VlTriggerVec<2> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vseries_tb__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vseries_tb___024root(Vseries_tb__Syms* symsp, const char* v__name);
    ~Vseries_tb___024root();
    VL_UNCOPYABLE(Vseries_tb___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
