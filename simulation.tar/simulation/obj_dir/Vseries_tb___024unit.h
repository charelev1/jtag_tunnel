// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vseries_tb.h for the primary calling header

#ifndef VERILATED_VSERIES_TB___024UNIT_H_
#define VERILATED_VSERIES_TB___024UNIT_H_  // guard

#include "verilated.h"
#include "verilated_timing.h"


class Vseries_tb__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vseries_tb___024unit final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    static VlUnpacked<std::string, 16> __Venumtab_enum_name0;

    // INTERNAL VARIABLES
    Vseries_tb__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vseries_tb___024unit(Vseries_tb__Syms* symsp, const char* v__name);
    ~Vseries_tb___024unit();
    VL_UNCOPYABLE(Vseries_tb___024unit);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
