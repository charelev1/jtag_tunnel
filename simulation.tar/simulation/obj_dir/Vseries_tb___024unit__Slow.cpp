// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vseries_tb.h for the primary calling header

#include "Vseries_tb__pch.h"
#include "Vseries_tb__Syms.h"
#include "Vseries_tb___024unit.h"
VlUnpacked<std::string, 16> Vseries_tb___024unit::__Venumtab_enum_name0;

void Vseries_tb___024unit___ctor_var_reset(Vseries_tb___024unit* vlSelf);

Vseries_tb___024unit::Vseries_tb___024unit(Vseries_tb__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vseries_tb___024unit___ctor_var_reset(this);
}

void Vseries_tb___024unit::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vseries_tb___024unit::~Vseries_tb___024unit() {
}
