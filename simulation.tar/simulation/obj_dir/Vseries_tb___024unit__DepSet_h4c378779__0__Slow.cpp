// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vseries_tb.h for the primary calling header

#include "Vseries_tb__pch.h"
#include "Vseries_tb___024unit.h"

VL_ATTR_COLD void Vseries_tb___024unit___ctor_var_reset(Vseries_tb___024unit* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+  Vseries_tb___024unit___ctor_var_reset\n"); );
    // Body
    for (int __Vi = 0; __Vi < 16; ++__Vi) {
        vlSelf->__Venumtab_enum_name0[__Vi] = std::string{""};
    }
    vlSelf->__Venumtab_enum_name0[0] = std::string{"TEST_LOGIC_RESET"};
    vlSelf->__Venumtab_enum_name0[1] = std::string{"RUN_TEST_IDLE"};
    vlSelf->__Venumtab_enum_name0[2] = std::string{"SELECT_DR"};
    vlSelf->__Venumtab_enum_name0[3] = std::string{"CAPTURE_DR"};
    vlSelf->__Venumtab_enum_name0[4] = std::string{"SHIFT_DR"};
    vlSelf->__Venumtab_enum_name0[5] = std::string{"EXIT1_DR"};
    vlSelf->__Venumtab_enum_name0[6] = std::string{"PAUSE_DR"};
    vlSelf->__Venumtab_enum_name0[7] = std::string{"EXIT2_DR"};
    vlSelf->__Venumtab_enum_name0[8] = std::string{"UPDATE_DR"};
    vlSelf->__Venumtab_enum_name0[9] = std::string{"SELECT_IR"};
    vlSelf->__Venumtab_enum_name0[10] = std::string{"CAPTURE_IR"};
    vlSelf->__Venumtab_enum_name0[11] = std::string{"SHIFT_IR"};
    vlSelf->__Venumtab_enum_name0[12] = std::string{"EXIT1_IR"};
    vlSelf->__Venumtab_enum_name0[13] = std::string{"PAUSE_IR"};
    vlSelf->__Venumtab_enum_name0[14] = std::string{"EXIT2_IR"};
    vlSelf->__Venumtab_enum_name0[15] = std::string{"UPDATE_IR"};
}
