// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vseries_tb.h for the primary calling header

#include "Vseries_tb__pch.h"
#include "Vseries_tb___024root.h"

VlCoroutine Vseries_tb___024root___eval_initial__TOP__Vtiming__0(Vseries_tb___024root* vlSelf);
VlCoroutine Vseries_tb___024root___eval_initial__TOP__Vtiming__1(Vseries_tb___024root* vlSelf);

void Vseries_tb___024root___eval_initial(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_initial\n"); );
    // Body
    Vseries_tb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vseries_tb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    vlSelf->__Vtrigprevexpr___TOP__jtag_tb__DOT__clk__0 
        = vlSelf->jtag_tb__DOT__clk;
}

VL_INLINE_OPT VlCoroutine Vseries_tb___024root___eval_initial__TOP__Vtiming__0(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_initial__TOP__Vtiming__0\n"); );
    // Init
    VlQueue<CData/*0:0*/> jtag_tb__DOT__dr_stream;
    jtag_tb__DOT__dr_stream.atDefault() = 0;
    VlQueue<CData/*0:0*/> __Vtask_jtag_tb__DOT__loadIR__0__stream;
    __Vtask_jtag_tb__DOT__loadIR__0__stream.atDefault() = 0;
    IData/*31:0*/ __Vtask_jtag_tb__DOT__loadIR__0__unnamedblk3__DOT__i;
    __Vtask_jtag_tb__DOT__loadIR__0__unnamedblk3__DOT__i = 0;
    VlQueue<CData/*0:0*/> __Vtask_jtag_tb__DOT__printStream__1__stream;
    __Vtask_jtag_tb__DOT__printStream__1__stream.atDefault() = 0;
    IData/*31:0*/ __Vtask_jtag_tb__DOT__printStream__1__unnamedblk2_1__DOT__i;
    __Vtask_jtag_tb__DOT__printStream__1__unnamedblk2_1__DOT__i = 0;
    VlQueue<CData/*0:0*/> __Vtask_jtag_tb__DOT__loadDR__3__stream;
    __Vtask_jtag_tb__DOT__loadDR__3__stream.atDefault() = 0;
    IData/*31:0*/ __Vtask_jtag_tb__DOT__loadDR__3__unnamedblk4__DOT__i;
    __Vtask_jtag_tb__DOT__loadDR__3__unnamedblk4__DOT__i = 0;
    VlQueue<CData/*0:0*/> __Vtask_jtag_tb__DOT__printStream__4__stream;
    __Vtask_jtag_tb__DOT__printStream__4__stream.atDefault() = 0;
    IData/*31:0*/ __Vtask_jtag_tb__DOT__printStream__4__unnamedblk2_1__DOT__i;
    __Vtask_jtag_tb__DOT__printStream__4__unnamedblk2_1__DOT__i = 0;
    VlQueue<CData/*0:0*/> __Vtask_jtag_tb__DOT__getDR__6__stream;
    __Vtask_jtag_tb__DOT__getDR__6__stream.atDefault() = 0;
    IData/*31:0*/ __Vtask_jtag_tb__DOT__getDR__6__size;
    __Vtask_jtag_tb__DOT__getDR__6__size = 0;
    IData/*31:0*/ __Vtask_jtag_tb__DOT__getDR__6__unnamedblk5__DOT__i;
    __Vtask_jtag_tb__DOT__getDR__6__unnamedblk5__DOT__i = 0;
    VlQueue<CData/*0:0*/> __Vtask_jtag_tb__DOT__printStream__8__stream;
    __Vtask_jtag_tb__DOT__printStream__8__stream.atDefault() = 0;
    IData/*31:0*/ __Vtask_jtag_tb__DOT__printStream__8__unnamedblk2_1__DOT__i;
    __Vtask_jtag_tb__DOT__printStream__8__unnamedblk2_1__DOT__i = 0;
    // Body
    __Vtask_jtag_tb__DOT__loadIR__0__stream = VlQueue<CData/*0:0*/>::cons(1U, 
                                                                          VlQueue<CData/*0:0*/>::cons(0U, 
                                                                                VlQueue<CData/*0:0*/>::cons(0U, 
                                                                                VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>()))))))))));
    VL_WRITEF("loadIR: ");
    __Vtask_jtag_tb__DOT__printStream__1__stream = __Vtask_jtag_tb__DOT__loadIR__0__stream;
    __Vtask_jtag_tb__DOT__printStream__1__unnamedblk2_1__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_jtag_tb__DOT__printStream__1__unnamedblk2_1__DOT__i, __Vtask_jtag_tb__DOT__printStream__1__stream.size())) {
        VL_WRITEF("%b",1,__Vtask_jtag_tb__DOT__printStream__1__stream.at(__Vtask_jtag_tb__DOT__printStream__1__unnamedblk2_1__DOT__i));
        __Vtask_jtag_tb__DOT__printStream__1__unnamedblk2_1__DOT__i 
            = ((IData)(1U) + __Vtask_jtag_tb__DOT__printStream__1__unnamedblk2_1__DOT__i);
    }
    VL_WRITEF("\n");
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       56);
    vlSelf->jtag_tb__DOT__tms = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       58);
    vlSelf->jtag_tb__DOT__tms = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       60);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       62);
    if (VL_LTS_III(32, 0U, __Vtask_jtag_tb__DOT__loadIR__0__stream.size())) {
        vlSelf->jtag_tb__DOT__tms = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "series_taps/series_tb.sv", 
                                           67);
        __Vtask_jtag_tb__DOT__loadIR__0__unnamedblk3__DOT__i = 0U;
        while (VL_LTS_III(32, __Vtask_jtag_tb__DOT__loadIR__0__unnamedblk3__DOT__i, __Vtask_jtag_tb__DOT__loadIR__0__stream.size())) {
            vlSelf->jtag_tb__DOT__tms = (__Vtask_jtag_tb__DOT__loadIR__0__unnamedblk3__DOT__i 
                                         == ((IData)(__Vtask_jtag_tb__DOT__loadIR__0__stream.size()) 
                                             - (IData)(1U)));
            vlSelf->jtag_tb__DOT__tdi = __Vtask_jtag_tb__DOT__loadIR__0__stream.at(__Vtask_jtag_tb__DOT__loadIR__0__unnamedblk3__DOT__i);
            co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                               nullptr, 
                                               "series_taps/series_tb.sv", 
                                               72);
            __Vtask_jtag_tb__DOT__loadIR__0__unnamedblk3__DOT__i 
                = ((IData)(1U) + __Vtask_jtag_tb__DOT__loadIR__0__unnamedblk3__DOT__i);
        }
    }
    vlSelf->jtag_tb__DOT__tms = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       78);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       80);
    VL_WRITEF("%b\n%b\n",5,vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR,
              5,(IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR));
    __Vtask_jtag_tb__DOT__loadDR__3__stream = VlQueue<CData/*0:0*/>::cons(0U, 
                                                                          VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>::cons(1U, 
                                                                                VlQueue<CData/*0:0*/>())));
    VL_WRITEF("loadDR: ");
    __Vtask_jtag_tb__DOT__printStream__4__stream = __Vtask_jtag_tb__DOT__loadDR__3__stream;
    __Vtask_jtag_tb__DOT__printStream__4__unnamedblk2_1__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_jtag_tb__DOT__printStream__4__unnamedblk2_1__DOT__i, __Vtask_jtag_tb__DOT__printStream__4__stream.size())) {
        VL_WRITEF("%b",1,__Vtask_jtag_tb__DOT__printStream__4__stream.at(__Vtask_jtag_tb__DOT__printStream__4__unnamedblk2_1__DOT__i));
        __Vtask_jtag_tb__DOT__printStream__4__unnamedblk2_1__DOT__i 
            = ((IData)(1U) + __Vtask_jtag_tb__DOT__printStream__4__unnamedblk2_1__DOT__i);
    }
    VL_WRITEF("\n");
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       97);
    vlSelf->jtag_tb__DOT__tms = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       99);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       101);
    if (VL_LTS_III(32, 0U, __Vtask_jtag_tb__DOT__loadDR__3__stream.size())) {
        vlSelf->jtag_tb__DOT__tms = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "series_taps/series_tb.sv", 
                                           106);
        __Vtask_jtag_tb__DOT__loadDR__3__unnamedblk4__DOT__i = 0U;
        while (VL_LTS_III(32, __Vtask_jtag_tb__DOT__loadDR__3__unnamedblk4__DOT__i, __Vtask_jtag_tb__DOT__loadDR__3__stream.size())) {
            vlSelf->jtag_tb__DOT__tms = (__Vtask_jtag_tb__DOT__loadDR__3__unnamedblk4__DOT__i 
                                         == ((IData)(__Vtask_jtag_tb__DOT__loadDR__3__stream.size()) 
                                             - (IData)(1U)));
            vlSelf->jtag_tb__DOT__tdi = __Vtask_jtag_tb__DOT__loadDR__3__stream.at(__Vtask_jtag_tb__DOT__loadDR__3__unnamedblk4__DOT__i);
            co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                               nullptr, 
                                               "series_taps/series_tb.sv", 
                                               111);
            __Vtask_jtag_tb__DOT__loadDR__3__unnamedblk4__DOT__i 
                = ((IData)(1U) + __Vtask_jtag_tb__DOT__loadDR__3__unnamedblk4__DOT__i);
        }
    }
    vlSelf->jtag_tb__DOT__tms = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       117);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       119);
    __Vtask_jtag_tb__DOT__getDR__6__size = 0x21U;
    __Vtask_jtag_tb__DOT__getDR__6__stream.renew(__Vtask_jtag_tb__DOT__getDR__6__size);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 1U;
    vlSelf->jtag_tb__DOT__tdi = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       34);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       129);
    vlSelf->jtag_tb__DOT__tms = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       131);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       133);
    if (VL_LTS_III(32, 0U, __Vtask_jtag_tb__DOT__getDR__6__stream.size())) {
        vlSelf->jtag_tb__DOT__tms = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "series_taps/series_tb.sv", 
                                           138);
        __Vtask_jtag_tb__DOT__getDR__6__unnamedblk5__DOT__i = 0U;
        while (VL_LTS_III(32, __Vtask_jtag_tb__DOT__getDR__6__unnamedblk5__DOT__i, __Vtask_jtag_tb__DOT__getDR__6__stream.size())) {
            vlSelf->jtag_tb__DOT__tms = (__Vtask_jtag_tb__DOT__getDR__6__unnamedblk5__DOT__i 
                                         == ((IData)(__Vtask_jtag_tb__DOT__getDR__6__stream.size()) 
                                             - (IData)(1U)));
            vlSelf->jtag_tb__DOT__tdi = 0U;
            __Vtask_jtag_tb__DOT__getDR__6__stream.at(__Vtask_jtag_tb__DOT__getDR__6__unnamedblk5__DOT__i) 
                = (1U & (((0x19U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR)) 
                          & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state))
                          ? VL_SHIFTR_III(32,32,32, vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR, 0x1fU)
                          : (((0x1fU == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR)) 
                              & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state))
                              ? (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BYPASS_SR)
                              : (((0x15U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR)) 
                                  & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state))
                                  ? (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR) 
                                           >> 7U)) : 
                                 (((0x13U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR)) 
                                   & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state))
                                   ? (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tdo_user)
                                   : ((0xbU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                       ? (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR) 
                                                >> 4U))
                                       : 0U))))));
            co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                               nullptr, 
                                               "series_taps/series_tb.sv", 
                                               144);
            __Vtask_jtag_tb__DOT__getDR__6__unnamedblk5__DOT__i 
                = ((IData)(1U) + __Vtask_jtag_tb__DOT__getDR__6__unnamedblk5__DOT__i);
        }
    }
    vlSelf->jtag_tb__DOT__tms = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       150);
    vlSelf->jtag_tb__DOT__tms = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "series_taps/series_tb.sv", 
                                       152);
    jtag_tb__DOT__dr_stream = __Vtask_jtag_tb__DOT__getDR__6__stream;
    VL_WRITEF("getDR: ");
    __Vtask_jtag_tb__DOT__printStream__8__stream = jtag_tb__DOT__dr_stream;
    __Vtask_jtag_tb__DOT__printStream__8__unnamedblk2_1__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_jtag_tb__DOT__printStream__8__unnamedblk2_1__DOT__i, __Vtask_jtag_tb__DOT__printStream__8__stream.size())) {
        VL_WRITEF("%b",1,__Vtask_jtag_tb__DOT__printStream__8__stream.at(__Vtask_jtag_tb__DOT__printStream__8__unnamedblk2_1__DOT__i));
        __Vtask_jtag_tb__DOT__printStream__8__unnamedblk2_1__DOT__i 
            = ((IData)(1U) + __Vtask_jtag_tb__DOT__printStream__8__unnamedblk2_1__DOT__i);
    }
    VL_WRITEF("\n");
    VL_FINISH_MT("series_taps/series_tb.sv", 177, "");
}

VL_INLINE_OPT VlCoroutine Vseries_tb___024root___eval_initial__TOP__Vtiming__1(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_initial__TOP__Vtiming__1\n"); );
    // Body
    while (1U) {
        co_await vlSelf->__VdlySched.delay(0x1f4ULL, 
                                           nullptr, 
                                           "series_taps/series_tb.sv", 
                                           15);
        vlSelf->jtag_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1f4ULL, 
                                           nullptr, 
                                           "series_taps/series_tb.sv", 
                                           16);
        vlSelf->jtag_tb__DOT__clk = 0U;
    }
}

void Vseries_tb___024root___eval_act(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_act\n"); );
}

VL_INLINE_OPT void Vseries_tb___024root___nba_sequent__TOP__0(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___nba_sequent__TOP__0\n"); );
    // Init
    IData/*31:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state = 0;
    CData/*4:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR = 0;
    CData/*4:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR = 0;
    IData/*31:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR = 0;
    CData/*7:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR = 0;
    IData/*31:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state = 0;
    CData/*4:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR = 0;
    CData/*4:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR = 0;
    IData/*31:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR = 0;
    CData/*7:0*/ __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR = 0;
    // Body
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR 
        = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR;
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state 
        = (((((((((0U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state) 
                  | (1U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
                 | (2U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
                | (3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
               | (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
              | (5U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
             | (6U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
            | (7U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state))
            ? ((0U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                    ? vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state
                    : 1U) : ((1U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                              ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                  ? 2U : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                              : ((2U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                  ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                      ? 9U : 3U) : 
                                 ((3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                   ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                       ? 5U : 4U) : 
                                  ((4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                    ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                        ? 5U : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                    : ((5U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                        ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                            ? 8U : 6U)
                                        : ((6U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                            ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                ? 7U
                                                : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                            : ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                ? 8U
                                                : 4U))))))))
            : (((((((((8U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state) 
                      | (9U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
                     | (0xaU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
                    | (0xbU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
                   | (0xcU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
                  | (0xdU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
                 | (0xeU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) 
                | (0xfU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state))
                ? ((8U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                    ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                        ? 2U : 1U) : ((9U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                       ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                           ? 0U : 0xaU)
                                       : ((0xaU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                           ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                               ? 0xcU
                                               : 0xbU)
                                           : ((0xbU 
                                               == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                               ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                   ? 0xcU
                                                   : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                               : ((0xcU 
                                                   == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                                   ? 
                                                  ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                    ? 0xfU
                                                    : 0xdU)
                                                   : 
                                                  ((0xdU 
                                                    == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                                    ? 
                                                   ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                     ? 0xeU
                                                     : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                                    : 
                                                   ((0xeU 
                                                     == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)
                                                     ? 
                                                    ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                      ? 0xfU
                                                      : 0xbU)
                                                     : 
                                                    ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                      ? 2U
                                                      : 1U))))))))
                : 0U));
    __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state 
        = (((((((((0U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state) 
                  | (1U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
                 | (2U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
                | (3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
               | (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
              | (5U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
             | (6U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
            | (7U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
            ? ((0U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                    ? vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state
                    : 1U) : ((1U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                              ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                  ? 2U : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                              : ((2U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                  ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                      ? 9U : 3U) : 
                                 ((3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                   ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                       ? 5U : 4U) : 
                                  ((4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                    ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                        ? 5U : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                    : ((5U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                        ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                            ? 8U : 6U)
                                        : ((6U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                            ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                ? 7U
                                                : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                            : ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                ? 8U
                                                : 4U))))))))
            : (((((((((8U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state) 
                      | (9U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
                     | (0xaU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
                    | (0xbU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
                   | (0xcU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
                  | (0xdU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
                 | (0xeU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) 
                | (0xfU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                ? ((8U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                    ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                        ? 2U : 1U) : ((9U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                       ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                           ? 0U : 0xaU)
                                       : ((0xaU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                           ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                               ? 0xcU
                                               : 0xbU)
                                           : ((0xbU 
                                               == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                               ? ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                   ? 0xcU
                                                   : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                               : ((0xcU 
                                                   == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                                   ? 
                                                  ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                    ? 0xfU
                                                    : 0xdU)
                                                   : 
                                                  ((0xdU 
                                                    == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                                    ? 
                                                   ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                     ? 0xeU
                                                     : vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                                    : 
                                                   ((0xeU 
                                                     == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                                     ? 
                                                    ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                      ? 0xfU
                                                      : 0xbU)
                                                     : 
                                                    ((IData)(vlSelf->jtag_tb__DOT__tms)
                                                      ? 2U
                                                      : 1U))))))))
                : 0U));
    if ((0x19U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR))) {
        if ((3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR = 0xdeaddeadU;
        }
        if ((4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR 
                = ((0xfffffff8U & __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR) 
                   | ((4U & (vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR 
                             << 1U)) | ((2U & (vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR 
                                               << 1U)) 
                                        | (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tdo0))));
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR 
                = ((7U & __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR) 
                   | (0xfffffff8U & (vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR 
                                     << 1U)));
        }
    }
    if ((0xaU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR 
            = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR;
    }
    if ((0xbU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR 
            = ((0x1eU & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR)) 
               | (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tdo0));
        vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0 
            = (1U & (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR));
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR 
            = ((0x1dU & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR)) 
               | ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0) 
                  << 1U));
        vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0 
            = (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR) 
                     >> 1U));
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR 
            = ((0x1bU & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR)) 
               | ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0) 
                  << 2U));
        vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0 
            = (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR) 
                     >> 2U));
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR 
            = ((0x17U & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR)) 
               | ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0) 
                  << 3U));
        vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0 
            = (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR) 
                     >> 3U));
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR 
            = ((0xfU & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR)) 
               | ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0) 
                  << 4U));
    }
    if ((0xfU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR 
            = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR;
    }
    if ((0x15U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR))) {
        if ((3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR 
                = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN;
        }
        if ((4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR 
                = ((0xf8U & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR)) 
                   | ((4U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR) 
                             << 1U)) | ((2U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR) 
                                               << 1U)) 
                                        | (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tdo0))));
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR 
                = ((7U & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR)) 
                   | (0xf8U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR) 
                               << 1U)));
        }
        if ((8U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
            vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN 
                = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR;
        }
    }
    if ((0x19U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR))) {
        if ((3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR = 0xdeadbeefU;
        }
        if ((4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR 
                = ((0xfffffff8U & __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR) 
                   | ((4U & (vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR 
                             << 1U)) | ((2U & (vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR 
                                               << 1U)) 
                                        | (IData)(vlSelf->jtag_tb__DOT__tdi))));
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR 
                = ((7U & __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR) 
                   | (0xfffffff8U & (vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR 
                                     << 1U)));
        }
    }
    if ((0x15U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR))) {
        if ((3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR 
                = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN;
        }
        if ((4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR 
                = ((0xf8U & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR)) 
                   | ((4U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR) 
                             << 1U)) | ((2U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR) 
                                               << 1U)) 
                                        | (IData)(vlSelf->jtag_tb__DOT__tdi))));
            __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR 
                = ((7U & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR)) 
                   | (0xf8U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR) 
                               << 1U)));
        }
        if ((8U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
            vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN 
                = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR;
        }
    }
    if ((0xaU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR 
            = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR;
    }
    if ((0xbU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR 
            = ((0x1eU & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR)) 
               | (IData)(vlSelf->jtag_tb__DOT__tdi));
        vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0 
            = (1U & (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR));
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR 
            = ((0x1dU & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR)) 
               | ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0) 
                  << 1U));
        vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0 
            = (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR) 
                     >> 1U));
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR 
            = ((0x1bU & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR)) 
               | ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0) 
                  << 2U));
        vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0 
            = (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR) 
                     >> 2U));
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR 
            = ((0x17U & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR)) 
               | ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0) 
                  << 3U));
        vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0 
            = (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR) 
                     >> 3U));
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR 
            = ((0xfU & (IData)(__Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR)) 
               | ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0) 
                  << 4U));
    }
    if ((0xfU == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
        __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR 
            = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR;
    }
    if ((0x1fU == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR))) {
        if ((3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
            vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BYPASS_SR = 0U;
        }
        if ((4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state)) {
            vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BYPASS_SR 
                = vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tdo0;
        }
    }
    if ((0x1fU == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR))) {
        if ((3U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
            vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BYPASS_SR = 0U;
        }
        if ((4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)) {
            vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BYPASS_SR 
                = vlSelf->jtag_tb__DOT__tdi;
        }
    }
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state 
        = __Vdly__jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tdo0 = 
        (1U & (((0x19U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR)) 
                & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                ? VL_SHIFTR_III(32,32,32, vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR, 0x1fU)
                : (((0x1fU == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR)) 
                    & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                    ? (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BYPASS_SR)
                    : (((0x15U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR)) 
                        & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                        ? (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR) 
                                 >> 7U)) : (((0x13U 
                                              == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR)) 
                                             & (4U 
                                                == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                                             ? (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tdo_user)
                                             : ((0xbU 
                                                 == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                                 ? 
                                                (1U 
                                                 & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR) 
                                                    >> 4U))
                                                 : 0U))))));
}

void Vseries_tb___024root___eval_nba(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_nba\n"); );
    // Body
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vseries_tb___024root___nba_sequent__TOP__0(vlSelf);
    }
}

void Vseries_tb___024root___timing_resume(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___timing_resume\n"); );
    // Body
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VdlySched.resume();
    }
}

void Vseries_tb___024root___eval_triggers__act(Vseries_tb___024root* vlSelf);

bool Vseries_tb___024root___eval_phase__act(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_phase__act\n"); );
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vseries_tb___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelf->__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
        vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
        Vseries_tb___024root___timing_resume(vlSelf);
        Vseries_tb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vseries_tb___024root___eval_phase__nba(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_phase__nba\n"); );
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelf->__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vseries_tb___024root___eval_nba(vlSelf);
        vlSelf->__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vseries_tb___024root___dump_triggers__nba(Vseries_tb___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vseries_tb___024root___dump_triggers__act(Vseries_tb___024root* vlSelf);
#endif  // VL_DEBUG

void Vseries_tb___024root___eval(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval\n"); );
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vseries_tb___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("series_taps/series_tb.sv", 4, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                Vseries_tb___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("series_taps/series_tb.sv", 4, "", "Active region did not converge.");
            }
            vlSelf->__VactIterCount = ((IData)(1U) 
                                       + vlSelf->__VactIterCount);
            vlSelf->__VactContinue = 0U;
            if (Vseries_tb___024root___eval_phase__act(vlSelf)) {
                vlSelf->__VactContinue = 1U;
            }
        }
        if (Vseries_tb___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vseries_tb___024root___eval_debug_assertions(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_debug_assertions\n"); );
}
#endif  // VL_DEBUG
