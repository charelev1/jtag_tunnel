// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vseries_tb.h for the primary calling header

#include "Vseries_tb__pch.h"
#include "Vseries_tb___024root.h"

VL_ATTR_COLD void Vseries_tb___024root___eval_static(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_static\n"); );
}

VL_ATTR_COLD void Vseries_tb___024root___eval_final(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_final\n"); );
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vseries_tb___024root___dump_triggers__stl(Vseries_tb___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vseries_tb___024root___eval_phase__stl(Vseries_tb___024root* vlSelf);

VL_ATTR_COLD void Vseries_tb___024root___eval_settle(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_settle\n"); );
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelf->__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY((0x64U < __VstlIterCount))) {
#ifdef VL_DEBUG
            Vseries_tb___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("series_taps/series_tb.sv", 4, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vseries_tb___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelf->__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vseries_tb___024root___dump_triggers__stl(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VstlTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vseries_tb___024root___stl_sequent__TOP__0(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___stl_sequent__TOP__0\n"); );
    // Body
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tdo0 = 
        (1U & (((0x19U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR)) 
                & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                ? VL_SHIFTR_III(32,32,32, vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR, 0x1fU)
                : (((0x1fU == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR)) 
                    & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                    ? (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BYPASS_SR)
                    : (((0x15U == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR)) 
                        & (4U == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                        ? (1U & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR) 
                                 >> 7U)) : (((0x13U 
                                              == (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR)) 
                                             & (4U 
                                                == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state))
                                             ? (IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tdo_user)
                                             : ((0xbU 
                                                 == vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state)
                                                 ? 
                                                (1U 
                                                 & ((IData)(vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR) 
                                                    >> 4U))
                                                 : 0U))))));
}

VL_ATTR_COLD void Vseries_tb___024root___eval_stl(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_stl\n"); );
    // Body
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        Vseries_tb___024root___stl_sequent__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD void Vseries_tb___024root___eval_triggers__stl(Vseries_tb___024root* vlSelf);

VL_ATTR_COLD bool Vseries_tb___024root___eval_phase__stl(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___eval_phase__stl\n"); );
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vseries_tb___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelf->__VstlTriggered.any();
    if (__VstlExecute) {
        Vseries_tb___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vseries_tb___024root___dump_triggers__act(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VactTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge jtag_tb.clk)\n");
    }
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vseries_tb___024root___dump_triggers__nba(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___dump_triggers__nba\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VnbaTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge jtag_tb.clk)\n");
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vseries_tb___024root___ctor_var_reset(Vseries_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vseries_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vseries_tb___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->jtag_tb__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__tms = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__tdi = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tdo0 = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tdo_user = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__tap_state = 0;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR = VL_RAND_RESET_I(5);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IR_SR = VL_RAND_RESET_I(5);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN = VL_RAND_RESET_I(8);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BCN_SR = VL_RAND_RESET_I(8);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__IDCODE_SR = VL_RAND_RESET_I(32);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT__BYPASS_SR = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_0__DOT____Vlvbound_h8271928f__0 = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tdo_user = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__tap_state = 0;
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR = VL_RAND_RESET_I(5);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IR_SR = VL_RAND_RESET_I(5);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN = VL_RAND_RESET_I(8);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BCN_SR = VL_RAND_RESET_I(8);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__IDCODE_SR = VL_RAND_RESET_I(32);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT__BYPASS_SR = VL_RAND_RESET_I(1);
    vlSelf->jtag_tb__DOT__jtag_taps_i__DOT__tap_1__DOT____Vlvbound_h8271928f__0 = VL_RAND_RESET_I(1);
    vlSelf->__Vtrigprevexpr___TOP__jtag_tb__DOT__clk__0 = VL_RAND_RESET_I(1);
}
